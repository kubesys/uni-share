package volume

import (
	"fmt"
)

func mirror() {
	fmt.Println("START MIRROR")
}
